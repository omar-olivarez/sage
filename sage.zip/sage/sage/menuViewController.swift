//
//  menuViewController.swift
//  sage
//
//  Created by Omar Olivarez on 10/28/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import UIKit

class menuViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Sage"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }



}

//
//  shoppingCartViewController.swift
//  sage
//
//  Created by Omar Olivarez on 10/28/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import UIKit

class shoppingCartViewController: UIViewController {
    
    //@IBOutlet weak var listTableView: UITableView!
    //private var shoppingcart = shoppingCart()
    var countVisits = 0;
    var alertController:UIAlertController? = nil
    var item: Grocery!
    private var shoppingcart = shoppingCart()
    @IBAction func bttnSimpleAlert(_ sender: Any) {
        
        self.alertController = UIAlertController(title: "Decision confirmation", message: "Would you like to add 1 banana to your cart?", preferredStyle: UIAlertControllerStyle.actionSheet)
        
        let ok = UIAlertAction(title: "Yes", style: UIAlertActionStyle.default, handler: { (action) -> Void in
            print("1 banana added")
        })
        let cancel = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: { (action) -> Void in
            print("Cancel Button Pressed")
        })
        
        self.alertController!.addAction(ok)
        self.alertController!.addAction(cancel)
        
        present(self.alertController!, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        countVisits = countVisits + 1;
        super.viewDidLoad()
        setNavBarTitle()
        createDataModel()
        // Do any additional setup after loading the view.
    }
    
    func createDataModel(){
        shoppingcart.addGrocery(name: "banana", price: "$0.50")
        shoppingcart.addGrocery(name: "promegranate", price: "$0.15")
    }
    
    private func setNavBarTitle() {
        self.title = "My Shopping Cart"
    }
    
    func numberOfSections(in listTableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ listTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shoppingcart.count()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        let backItem = UIBarButtonItem()
        backItem.title = "My Shopping Cart"
        navigationItem.backBarButtonItem = backItem
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath)
        let item = shoppingcart.getGrocery(index: indexPath.row)
        print("you made it here")
        cell.textLabel?.text = item.name
        return cell
    }
    
}

//
//  myTableViewController.swift
//  sage
//
//  Created by Omar Olivarez on 10/29/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import UIKit

class myTableViewController: UITableViewController {

    // This is the data model.
    private var shoppingcart = shoppingCart()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setNavBarTitle()
        
        createDataModelObjects()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    private func setNavBarTitle() {
        self.title = "My Shopping Cart"
    }
    
    private func createDataModelObjects() {
        shoppingcart.addGrocery(name: "banana", price: "$0.50")
        shoppingcart.addGrocery(name: "orange", price: "$0.15")
        shoppingcart.addGrocery(name: "promegranate", price: "$0.40")
        shoppingcart.addGrocery(name: "lemon", price: "$0.10")
        shoppingcart.addGrocery(name: "pumpkin", price: "$2.35")
        shoppingcart.addGrocery(name: "kiwi", price: "$0.15")
        shoppingcart.addGrocery(name: "bread", price: "$1.00")
        shoppingcart.addGrocery(name: "milk", price: "$2.20")
        shoppingcart.addGrocery(name: "ice cream", price: "$3.50")
        shoppingcart.addGrocery(name: "water bottle", price: "$0.50")
        shoppingcart.addGrocery(name: "soda", price: "$1.15")
        shoppingcart.addGrocery(name: "shampoo", price: "$0.40")
        shoppingcart.addGrocery(name: "chocolate bar", price: "$1.10")
        shoppingcart.addGrocery(name: "chicken nuggets", price: "$6.35")
        shoppingcart.addGrocery(name: "tea", price: "$3.15")
        shoppingcart.addGrocery(name: "peanuts", price: "$1.00")
        shoppingcart.addGrocery(name: "apple", price: "$2.20")
        shoppingcart.addGrocery(name: "salsa", price: "$3.50")
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shoppingcart.count()
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellid", for: indexPath)
        
        // Configure the cell...
        let item = shoppingcart.getGrocery(index: indexPath.row)
        
        cell.textLabel?.text = item.name
        cell.detailTextLabel?.text = item.price

        return cell
    }
}

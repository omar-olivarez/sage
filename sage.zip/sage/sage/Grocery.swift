//
//  Grocery.swift
//  sage
//
//  Created by Omar Olivarez on 10/29/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import Foundation
class Grocery {
    
    var name: String = ""
    var price: String = ""
    
    init() {
    }
    
    init(name: String, price: String) {
        self.name = name
        self.price = price
    }
}

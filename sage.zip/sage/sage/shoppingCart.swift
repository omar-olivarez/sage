//
//  shoppingCart.swift
//  sage
//
//  Created by Omar Olivarez on 10/29/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import Foundation

class shoppingCart {
    private var shoppingcart = [Grocery]()
    
    func count() -> Int {
        return shoppingcart.count
    }
    
    func addGrocery(name: String, price: String) {
        shoppingcart.append(Grocery(name: name, price: price))
    }
    
    func getGrocery(index: Int) -> Grocery {
        guard index < shoppingcart.count else { return Grocery() }
        return shoppingcart[index]
    }

}

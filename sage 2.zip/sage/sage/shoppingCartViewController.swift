//
//  shoppingCartViewController.swift
//  sage
//
//  Created by Omar Olivarez on 10/28/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import UIKit

class shoppingCartViewController: UIViewController {
    
    //@IBOutlet weak var listTableView: UITableView!
    //private var shoppingcart = shoppingCart()
    var countVisits = 0;
    override func viewDidLoad() {
        countVisits = countVisits + 1;
        super.viewDidLoad()
        setNavBarTitle()
        // Do any additional setup after loading the view.
    }
    
    private func setNavBarTitle() {
        print("2");
        self.title = "My Shopping Cart"
    }
    /*
    func numberOfSections(in listTableView: UITableView) -> Int {
        print("3");
        return 1
    }
    
    func tableView(_ listTableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("4");
        return shoppingcart.count()
    } */

    override func didReceiveMemoryWarning() {
        print("5");
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("6");
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        let backItem = UIBarButtonItem()
        backItem.title = "My Shopping Cart"
        navigationItem.backBarButtonItem = backItem
    }
    
}

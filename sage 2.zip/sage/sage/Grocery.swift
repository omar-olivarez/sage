//
//  Grocery.swift
//  sage
//
//  Created by Omar Olivarez on 10/29/17.
//  Copyright © 2017 Omar Olivarez. All rights reserved.
//

import Foundation
class Grocery {
    
    private var name: String = ""
    private var price: Float = 0.0
    
    init() {
    }
    
    init(name: String) {
        self.name = name
        if (self.name == "banana"){
            self.price = 0.4
        } else if self.name == "orange" {
            self.price = 0.15
        } else if self.name == "Granny Smith" {
            self.price = 0.5
        } else {
            self.price = 0.0
        }
    }
}
